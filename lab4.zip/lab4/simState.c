#include <stdlib.h>
#include<stdio.h>
/**
A F D
B G E
C C A
D F G
E C H
F E H
G B C
H D B 

Your starting state is: E 
**/

/**The lab is sucessful in its excecuiton**/

         int main(int argc, char * argv[])

   {	
	int i;
         int j=0; 
int ctr;
char in[3];
int check=0;
int f;
int k; 
int t;

typedef struct state{
char name; struct state* low;
struct state *hi;
int reach;
}state;

state s[8];
state *start= (&s[4]);


s[0].name= 'A';
s[0].low= &s[5];
s[0].hi=&s[3];

s[1].name= 'B';
s[1].low= &s[6];
s[1].hi=&s[4];

s[2].name= 'C';
s[2].low= &s[2];
s[2].hi=&s[0];

s[3].name= 'D';
s[3].low= &s[5];
s[3].hi=&s[6];

s[4].name= 'E';
s[4].low= &s[2];
s[4].hi=&s[7];

s[5].name= 'F';
s[5].low= &s[4];
s[5].hi=&s[7];

s[6].name= 'G';
s[6].low= &s[1];
s[6].hi=&s[2];

s[7].name= 'H';
s[7].low= &s[3];
s[7].hi=&s[1];

state *current = &s[4];
fprintf(stdout, "start: %c\n", start-> name);
printf("Insert commands with no space between characters. \nEx (0c) to print the state linked to C low. \nComplete command with character x.\n");

while(j!=1)

{
	int a,l,m;
	for(a=0;a<8;a++){
	s[a].reach=0;}

	for(l=0;l<8;l++){

	for(m=0;m<8;m++){
	if(s[l].name==s[m].low->name|| s[l].name==s[m].hi->name){
	s[l].reach=1;
	}}}






	for(i=0;i<3;i++){
	scanf("%c", &in[i]);
	if(in[i]=='\n'){
	break;
}
}

	if(in[0]=='x' || in[0]=='X')
{
	j=1;
			}

if(in[0]=='p' || in[0]=='P')
{
for(i=0;i<8;i++)
{
	fprintf(stdout, "%c %c %c \n", s[i].name, s[i].low ->name, s[i].hi->name);
}
}
	if(in[0]=='0')
	{
		fprintf(stdout, "%c\n", (current-> low)->name);
		current =(current ->low);
			}
	
	if(in[0]=='1')
	{
		fprintf(stdout, "%c\n", (current-> hi)->name);
		current =(current ->hi);
			}

	if((in[0]=='c' || in[0]=='C')&& in[1]=='0'){
	
	if((in[2]=='a' || in[2]== 'A')&& s[0] == 'A'){
	(current -> low)= &s[0];
	current= &s[0];
			}

	else if((in[2]=='b' || in[2]== 'B')&& s[1] == 'B'){
	(current -> low)= &s[1];
	current=&s[1];
			}
	else if((in[2]=='c' || in[2]== 'C')&& s[1] == 'C'){
	(current -> low)= &s[2];
	current=&s[2];
			}
	else if((in[2]=='d' || in[2]== 'D')&& s[1] == 'D'){
	(current -> low)= &s[3];
	current=&s[3];
			}
	else if((in[2]=='e' || in[2]== 'E')&& s[1] == 'E'){
	(current -> low)= &s[4];
	current=&s[4];
			}
	else if((in[2]=='f' || in[2]== 'F')&& s[1] == 'F'){
	(current -> low)= &s[5];
	current=&s[5];
			}
	else if((in[2]=='g' || in[2]== 'G')&& s[1] == 'G'){
	(current -> low)= &s[6];
	current=&s[6];
			}
	else if((in[2]=='h' || in[2]== 'H')&& s[1] == 'H'){
	(current -> low) =&s[7];
	current=&s[7];
			}

					}

	
if((in[0]=='c' || in[0]=='C')&& in[1]=='1'){
	
	if((in[2]=='a' || in[2]== 'A')&& s[1] == 'A'){
	(current -> hi)= &s[0];
	current= &s[0];
			}

	else if((in[2]=='b' || in[2]== 'B')&& s[1] == 'B'){
	(current -> hi) =&s[1];
	current= &s[1];
			}
	else if((in[2]=='c' || in[2]== 'C')&& s[1] == 'C'){
	(current -> hi)= &s[2];
	current= &s[2];
			}
	else if((in[2]=='d' || in[2]== 'D')&& s[1] == 'D'){
	(current -> hi)= &s[3];
	current= &s[3];
			}
	else if((in[2]=='e' || in[2]== 'E')&& s[1] == 'E'){
	(current -> hi) =&s[4];
	current= &s[4];
			}
	else if((in[2]=='f' || in[2]== 'F')&& s[1] == 'F'){
	(current -> hi)= &s[5];
	current= &s[5];
			}
	else if((in[2]=='g' || in[2]== 'G')&& s[1] == 'G'){
	(current -> hi)= &s[6];
	current= &s[6];
			}
	else if((in[2]=='h' || in[2]== 'H')&& s[1] == 'H'){
	(current -> hi)= &s[7];
	current= &s[7];
			}

	else{
		fprintf(stdout, "invaild command only A-H");
								}

					}



if(in[0]== 'g' || in[0]=='G'){

		for(f=0;f<8;f++)
		{
			if(s[f].reach==0){
			check=1;}}
		
		if(check==1)

		{
			printf("Garbage value:");
for(i=0; i<8; i++)
		{
			if(s[i].reach==0){
			printf("%c \n", s[i].name);
			}}
						}



		else if(check==0)
		{
			printf("No Garbage value\n");
							}
	
							}

if(in[0] == 'd' || in[0] == 'D')
{
	for(i=0; i<8; i++)
		{
			if(s[i].reach==0)
			{
				printf("Deleted state: %c \n", s[i].name);
				s[i].name = ' ';
			}
		}

}


}//exits while
	
    exit(0);

}

