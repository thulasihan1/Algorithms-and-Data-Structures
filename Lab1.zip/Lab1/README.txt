/* mySort() function using the signature */


#include "betterSort.h"
void mySort(int data[], int n)
{
	betterSort(int data[], int data[0], int data[n-1]);
				
							}

