#include "mySort.h"

void mySort(int array[], unsigned int first, unsigned int last)
    {
if(first<last)
{
int mid= (first +last)/2;
mySort(array, first, mid);
mySort(array, mid+1, last);
merge(array, first, mid, mid+1, last);
}

}



void merge(int a[], int x1, int y1, int x2, int y2)
{

	int temp[MAX_SIZE_N_TO_SORT];
	int x= x1;
	int y=x2;
	int z=0;

	while(x <= y1 && y <= y2)
	{
	
		if(myCompare(a[x], a[y]) < 0)
		{

			temp[z++]= a[x++];
			}

		else
		{
			temp[z++]= a[y++];
			}

					}
	
	while(y<=y2)
	{
		myCopy(&a[y++], &temp[z++]);
						}

	while(x<= y1)
	{
		myCopy(&a[x++], &temp[z++]);
						}

	for(x=x1, z=0;x<=y2;x++,z++)
	{
		mySwap(&a[x], &temp[z]);
					}
						


}

					 
