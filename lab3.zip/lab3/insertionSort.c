#include "mySort.h"
#include <stdlib.h>
#include <stdio.h>

void 
mySort(int array[], unsigned int first, unsigned int last)
{
	int i;
	int j;
	int key;

	for(j=first;j<=last;j++)
	{
		/*key= array[j];*/
		myCopy(&array[j],&key);
		i=j-1;
		while(i>-1 && array[i]>key)
		{
			/*array[i+1]= array[i];
			array[i+1]=key; */
			mySwap(&array[i+1],&array[i]);
			i=i-1;

		}
	}
						
}
