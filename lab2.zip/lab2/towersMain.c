#include "towers.h"
#include<stdlib.h>
#include<stdio.h>

int main(int argc, char **argv)
{
 int dest = 2;
    int n = 3;
    int from = 1;
   
	
	if(argc == 1)
	{
		towers(n, from, dest);    
	}
	

	if(argc == 2)
	{
		n = atoi(argv[1]);
		towers(n, from, dest);
	}

	if (argc == 3)
    {
		printf("Not enough arguments!");
		exit(1);
    }

	
	if(argc == 4)
	{
		n = atoi(argv[1]);
		from = atoi(argv[2]);
		dest = atoi(argv[3]);
		towers(n, from, dest);	
	}

if (argc > 4){
printf("the value for the argument cannot exceed 3!");
exit(1);
			}


	exit(0);
}

