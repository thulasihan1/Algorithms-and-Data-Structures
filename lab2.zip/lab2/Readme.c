With in Lab2 I achieved the basic understanding of recursion and we learned about the recursive algorithm Towers of Hanoi. 

Question 1:
It would be invoked like this;
towers(5, 2, 3)
..towers(4,2, 1)
...towers(3, 2, 3)
....towers(2, 2, 1)
.....towers(1, 2, 3)
......towers(0, 2, 1)
.......Move #1 From Tower 2 to Tower 3
2 3
Question 2:
31 recursive calls to towers() will be made before the first recursive call. 

Question 3:
Move #1: From Tower 2 to Tower 3
Question 4:
The second recursive call to towers() will be invoked like this;
..........towers(0, 1, 3)
........Move #2: from Tower 2 to Tower 1
2 1

If towers(8, 1 ,2) is invoked 255 lines will be printed to stdout. 
